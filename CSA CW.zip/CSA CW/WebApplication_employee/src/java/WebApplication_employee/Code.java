/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebApplication_employee;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class Code {
    public static boolean login_operation (String username, String password) throws Exception{
//connection
        Connection con = getConnection();
        //execute sql query
        PreparedStatement pst = con.prepareStatement("Select username, password from employee2 where username=? and password=?");
        pst.setString(1, username);
        pst.setString(2, password);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            return true;
        } else {
            throw new Exception("Incorrect Login");
            // return false;
        }
}
    
    
    public static void addEmployee_operation( String username, String password,String name, String position) {
        //inserting data into employee table
        String query = "insert into employee2 (username,password,name,position) values ('" + username + "','" + password + "','" + name + "','" + position + "')";

       /* try {
            //make connection
            Connection c = getConnection();
            Statement stmt = c.createStatement();
            stmt.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Saved");

        } catch (Exception e) {
            e.printStackTrace();
        }
        */
        try {
            if (username.isEmpty() == true || password.isEmpty() == true || name.isEmpty() == true || position.isEmpty() == true) {
                throw new Exception("Empty Fields detected !! Please fill all Fields");

            } else {
                //make connection
                Connection con = getConnection();
                PreparedStatement pst = con.prepareStatement("Select username from employee2 where username='" + username + "'");

                ResultSet result = pst.executeQuery();
                if (result.next()) {
                    throw new Exception("Username is existing! please try another username");

                } else {
                    Statement stmt = con.createStatement();
                    stmt.executeUpdate(query);
                    JOptionPane.showMessageDialog(null, "Employee successfully registered!");
                    
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    
    public static void editEmployee_operation( String currentusername,String username, String password, String name, String position) {

        //updating employee details
        String query = "Update employee2 set name='" + name + "'" + ",position='" + position + "'" + ",username='" + username + "'" + ",password='" + password + "'" + "where username='" + currentusername + "'";

        try {
            //make connection
            Connection c = getConnection();
            Statement stmt = c.createStatement();
            
            PreparedStatement pst = c.prepareStatement("Select username from employee2 where username='" + currentusername + "'");

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
            stmt.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Employee updated");

            } else {
            throw new Exception("username not found");
            }
            
            

        } catch (Exception e) {
            e.printStackTrace();
        } 

    }
    
    public static void deleteEmployee_operation(String username) {
        String query = "delete from employee2 where username='" + username + "'";
        try {
            //make connection
            Connection c = getConnection();
            Statement stmt = c.createStatement();
            stmt.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Employee deleted");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    
     public static Connection getConnection() throws Exception {
          Connection connection = null;
        if (connection == null) {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/csa_cw", "root", "");
            
        }
        return connection;
    }
    
}
