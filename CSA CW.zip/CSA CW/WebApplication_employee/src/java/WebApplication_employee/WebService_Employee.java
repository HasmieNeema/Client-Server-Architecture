/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebApplication_employee;

import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author DELL
 */
@WebService(serviceName = "WebService_Employee")
public class WebService_Employee {
    
    Code c= new Code();

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "login_operation")
    public boolean login_operation(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        try{
          return c.login_operation(username, password);
        }catch(Exception ex){
            return false;
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addEmployee_operation")
    @Oneway
    public void addEmployee_operation(@WebParam(name = "username") String username, @WebParam(name = "password") String password, @WebParam(name = "name") String name, @WebParam(name = "position") String position) {
        c.addEmployee_operation(username, password, name, position);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "editEmployee_operation")
    @Oneway
    public void editEmployee_operation(@WebParam(name = "currentusername") String currentusername, @WebParam(name = "username") String username, @WebParam(name = "password") String password, @WebParam(name = "name") String name, @WebParam(name = "position") String position) {
        c.editEmployee_operation(currentusername,username, password, name, position);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "deleteEmployee_operation")
    @Oneway
    public void deleteEmployee_operation(@WebParam(name = "username") String username) {
        c.deleteEmployee_operation(username);
    }


}
