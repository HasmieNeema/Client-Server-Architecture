create database and  import the sql file
	db name : csa_cw
	user : root
	pw : ""

