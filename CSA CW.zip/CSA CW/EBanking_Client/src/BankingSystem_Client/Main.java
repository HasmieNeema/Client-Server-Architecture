/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BankingSystem_Client;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class Main {
    
    public static void main(String[] args){
        // set the look and feel of GUI
        try {

            // show login ui
            WelcomePage wel = new WelcomePage();
            wel.setVisible(true);

        } catch (Exception e) {
            
            // error
            JOptionPane.showMessageDialog(new JFrame(), e.getLocalizedMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
            
        }
    }
    
}
