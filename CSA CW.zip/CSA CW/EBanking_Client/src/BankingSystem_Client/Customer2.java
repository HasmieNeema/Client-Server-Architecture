/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BankingSystem_Client;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author DELL
 */
@Entity
@Table(name = "customer2", catalog = "csa_cw", schema = "")
@NamedQueries({
    @NamedQuery(name = "Customer2.findAll", query = "SELECT c FROM Customer2 c")
    , @NamedQuery(name = "Customer2.findByName", query = "SELECT c FROM Customer2 c WHERE c.name = :name")
    , @NamedQuery(name = "Customer2.findByBirthdate", query = "SELECT c FROM Customer2 c WHERE c.birthdate = :birthdate")
    , @NamedQuery(name = "Customer2.findByAddress", query = "SELECT c FROM Customer2 c WHERE c.address = :address")
    , @NamedQuery(name = "Customer2.findByMobile", query = "SELECT c FROM Customer2 c WHERE c.mobile = :mobile")
    , @NamedQuery(name = "Customer2.findByEmail", query = "SELECT c FROM Customer2 c WHERE c.email = :email")
    , @NamedQuery(name = "Customer2.findByAccType", query = "SELECT c FROM Customer2 c WHERE c.accType = :accType")
    , @NamedQuery(name = "Customer2.findByAccNo", query = "SELECT c FROM Customer2 c WHERE c.accNo = :accNo")
    , @NamedQuery(name = "Customer2.findBySortCode", query = "SELECT c FROM Customer2 c WHERE c.sortCode = :sortCode")
    , @NamedQuery(name = "Customer2.findByBalance", query = "SELECT c FROM Customer2 c WHERE c.balance = :balance")
    , @NamedQuery(name = "Customer2.findByCardNo", query = "SELECT c FROM Customer2 c WHERE c.cardNo = :cardNo")})
public class Customer2 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Column(name = "birthdate")
    @Temporal(TemporalType.DATE)
    private Date birthdate;
    @Basic(optional = false)
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @Column(name = "mobile")
    private String mobile;
    @Basic(optional = false)
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @Column(name = "acc_type")
    private String accType;
    @Id
    @Basic(optional = false)
    @Column(name = "acc_no")
    private String accNo;
    @Basic(optional = false)
    @Column(name = "sort_code")
    private String sortCode;
    @Basic(optional = false)
    @Column(name = "balance")
    private double balance;
    @Basic(optional = false)
    @Column(name = "card_no")
    private String cardNo;

    public Customer2() {
    }

    public Customer2(String accNo) {
        this.accNo = accNo;
    }

    public Customer2(String accNo, String name, Date birthdate, String address, String mobile, String email, String accType, String sortCode, double balance, String cardNo) {
        this.accNo = accNo;
        this.name = name;
        this.birthdate = birthdate;
        this.address = address;
        this.mobile = mobile;
        this.email = email;
        this.accType = accType;
        this.sortCode = sortCode;
        this.balance = balance;
        this.cardNo = cardNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        String oldName = this.name;
        this.name = name;
        changeSupport.firePropertyChange("name", oldName, name);
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        Date oldBirthdate = this.birthdate;
        this.birthdate = birthdate;
        changeSupport.firePropertyChange("birthdate", oldBirthdate, birthdate);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        String oldAddress = this.address;
        this.address = address;
        changeSupport.firePropertyChange("address", oldAddress, address);
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        String oldMobile = this.mobile;
        this.mobile = mobile;
        changeSupport.firePropertyChange("mobile", oldMobile, mobile);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        String oldEmail = this.email;
        this.email = email;
        changeSupport.firePropertyChange("email", oldEmail, email);
    }

    public String getAccType() {
        return accType;
    }

    public void setAccType(String accType) {
        String oldAccType = this.accType;
        this.accType = accType;
        changeSupport.firePropertyChange("accType", oldAccType, accType);
    }

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        String oldAccNo = this.accNo;
        this.accNo = accNo;
        changeSupport.firePropertyChange("accNo", oldAccNo, accNo);
    }

    public String getSortCode() {
        return sortCode;
    }

    public void setSortCode(String sortCode) {
        String oldSortCode = this.sortCode;
        this.sortCode = sortCode;
        changeSupport.firePropertyChange("sortCode", oldSortCode, sortCode);
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        double oldBalance = this.balance;
        this.balance = balance;
        changeSupport.firePropertyChange("balance", oldBalance, balance);
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        String oldCardNo = this.cardNo;
        this.cardNo = cardNo;
        changeSupport.firePropertyChange("cardNo", oldCardNo, cardNo);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (accNo != null ? accNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customer2)) {
            return false;
        }
        Customer2 other = (Customer2) object;
        if ((this.accNo == null && other.accNo != null) || (this.accNo != null && !this.accNo.equals(other.accNo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "BankingSystem_Client.Customer2[ accNo=" + accNo + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
