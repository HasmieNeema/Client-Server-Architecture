-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2017 at 12:23 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `csa_cw`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer2`
--

CREATE TABLE IF NOT EXISTS `customer2` (
  `name` varchar(50) NOT NULL,
  `birthdate` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `acc_type` varchar(10) NOT NULL,
  `acc_no` varchar(10) NOT NULL,
  `sort_code` varchar(10) NOT NULL,
  `balance` double NOT NULL,
  `card_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer2`
--

INSERT INTO `customer2` (`name`, `birthdate`, `address`, `mobile`, `email`, `acc_type`, `acc_no`, `sort_code`, `balance`, `card_no`) VALUES
('Sam', '1980-09-04', 'Colombo', '0772878096', 'sam@hotmail.com', 'fixed', '1000001', '1234', 10000, '12345'),
('John', '1999-07-09', 'Galle', '078654534', 'john@hotmail.com', 'fixed', '2000003', '212121', 400000, '1219'),
('Ben', '1970-05-09', 'Nugegoda', '0778998898', 'sam@gmail.com', 'fixed', '4000003', '8887', 12000, '1212'),
('Ann', '1969-07-02', 'Maharagama', '0777786234', 'ann@gmail.com', 'deposit', '9000003', '56788', 6000, '45666');

-- --------------------------------------------------------

--
-- Table structure for table `employee2`
--

CREATE TABLE IF NOT EXISTS `employee2` (
  `name` varchar(20) NOT NULL,
  `position` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee2`
--

INSERT INTO `employee2` (`name`, `position`, `username`, `password`) VALUES
('Dewni', 'manager', 'dewni', '1234'),
('Jack', 'accountant', 'jack', '1234'),
('Matheesha', 'ceo', 'matheesha', '1234'),
('Peter', 'director', 'peter', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer2`
--
ALTER TABLE `customer2`
 ADD PRIMARY KEY (`acc_no`);

--
-- Indexes for table `employee2`
--
ALTER TABLE `employee2`
 ADD PRIMARY KEY (`username`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
