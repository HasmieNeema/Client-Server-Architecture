/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebApplication_customer;

import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author DELL
 */
@WebService(serviceName = "WebService_Customer")
public class WebService_Customer {
    
    Code c= new Code();

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addCustomer_operation")
    @Oneway
    public void addCustomer_operation(@WebParam(name = "name") String name, @WebParam(name = "birthdate") String birthdate, @WebParam(name = "address") String address, @WebParam(name = "mobile") String mobile, @WebParam(name = "email") String email, @WebParam(name = "acc_type") String acc_type, @WebParam(name = "acc_no") String acc_no, @WebParam(name = "sort_code") String sort_code, @WebParam(name = "balance") double balance, @WebParam(name = "card_no") String card_no) {
        c.addCustomer_operation(name, birthdate, address, mobile, email, acc_type, acc_no, sort_code, balance, card_no);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "deleteCustomer_operation")
    @Oneway
    public void deleteCustomer_operation(@WebParam(name = "acc_no") String acc_no) {
        c.deleteCustomer_operation(acc_no);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "editCustomer_operation")
    @Oneway
    public void editCustomer_operation(@WebParam(name = "name") String name, @WebParam(name = "address") String address, @WebParam(name = "mobile") String mobile, @WebParam(name = "birthdate") String birthdate, @WebParam(name = "email") String email, @WebParam(name = "acc_type") String acc_type, @WebParam(name = "acc_no") String acc_no, @WebParam(name = "sort_code") String sort_code, @WebParam(name = "card_no") String card_no, @WebParam(name = "balance") double balance) {
    c.editCustomer_operation(name,address, mobile,birthdate, email, acc_type, acc_no,  sort_code, balance, card_no);
    }



}
