/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebApplication_customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class Code {
    
    
public static void addCustomer_operation(String name, String birthdate, String address, String mobile, String email, String acc_type, String acc_no, String sort_code, double balance, String card_no) {
        //sql query to insert data into the table
        String query = "insert into customer2(name, birthdate, address, mobile, email, acc_type, acc_no, sort_code, balance, card_no)  values ('" + name + "','" + birthdate + "','" + address + "','" + mobile + "','" + email + "','" + acc_type + "','" + acc_no + "','" + sort_code + "','" + balance + "','" + card_no + "')";

        
         
        try {
            if (name.isEmpty() == true || birthdate.isEmpty() == true || address.isEmpty() == true || mobile.isEmpty() == true || email.isEmpty() == true || acc_type.isEmpty() == true || acc_no.isEmpty() == true || sort_code.isEmpty() == true) {
            throw new Exception("Please fill all the mandatory fields");

        }
            else {
            //make connection
            Connection c = getConnection();
            Statement stmt = c.createStatement();
            stmt.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Saved");
        }
            

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


public static void editCustomer_operation(String name,String address, String mobile,String birthdate,   String email, String acc_type, String acc_no, String sort_code, double balance, String card_no) {

        //Query to update selected employee's details
        String query = "Update customer2 set name='" + name + "'" + ",address='" + address + "'" + ",mobile='" + mobile + "'" + ",birthdate='" + birthdate + "'" + ",email='" + email + "'" + ",acc_type='" + acc_type + "'" + ",sort_code='" + sort_code + "'" + ",balance='" + balance + "'" + ",card_no='" + card_no + "'"
                + "where acc_no='" + acc_no + "'";

        try {
            //make connection
            Connection c = getConnection();
            Statement stmt = c.createStatement();
            stmt.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Updated");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

     public static void deleteCustomer_operation(String acc_no) {
        String query = "delete from customer2 where acc_no='" + acc_no + "'";
        try {
            //make connection
            Connection c = getConnection();
            Statement stmt = c.createStatement();
            stmt.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Deleted");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
     
     
     
    public static Connection getConnection() throws Exception {
        Connection connection = null;
        if (connection == null) {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/csa_cw", "root", "");
            
        }
        return connection;
    }
    
}
